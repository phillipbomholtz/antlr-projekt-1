#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int enterCmd(char *cmd, char *arg); // divides the entered command into 'command' and 'argument'.
void onlyCmd(char *cmd);            // function for commands without arguments
void cmdwArg(char *cmd, char *arg); // function for commands with arguments
void cdCall(char *arg);             // function for 'cd' command.

int main()
{
    char cmd[20];       //Entered command
    char arg[20];       // Entered Argument
    printf("\nThis is the working directory shell.\n");
    printf("This shell accepts a variation of inputs, like commands such as 'ls'\n");
    printf("Furthermore commdans with one appendix such as 'ls - a' .\n");
    printf("Enter the commad 'Stop' to exit the shell.\n");

    while (1)
    {
        printf("PID of test.c = %d\n", getpid());
        int valid = enterCmd(cmd, arg);     //valid returns 0 for unrecognized command,
                                            // 1 for command without argument and 
                                            // 2 for command with argument.

        if (valid == 0)
        {
            puts("entered command not recognized or supported");
        }

        if (valid == 1)
        {
            if (strcmp(cmd, "stop") == 0)
            {
                printf("Extiting shell.\n");
                return 0;
            }
            onlyCmd(cmd);       
        }

        if (valid == 2)
        {
            if (strcmp(cmd, "cd") == 0)
            {
                cdCall(arg);
            }
            else
            
                cmdwArg(cmd, arg);
            
        }
    }
}
int enterCmd(char *cmd, char *arg)      //Handles user input 
{
    char command[20];

    printf("Enter command:");
    fgets(command, 20, stdin);
    unsigned int commandLength = strlen(command); //reads size of input

    char *space;                    //pointer to space character
    space = strchr(command, ' ');
    if (space == NULL)
    {
        strncpy(cmd, command, 19);              //copy command to cmd
        char *lFeed = strchr(command, 10);      //pointer to linefeed character    
        int wrlFeed = (int)(lFeed - command);   //position of linefeed character 
        cmd[wrlFeed] = 0;                       
        arg[0] = 0;

        return 1;                               //return 1 for command without argument
    }
    else if (space != NULL) // there was a space, thus the user entered a command with an argument
    {
        int wrSpace = (int)(space - command);   //position of space character
        cmd = strncpy(cmd, command, wrSpace);
        cmd[wrSpace] = 0;
        arg = strncpy(arg, space + 1, 19);      

        char *nL = strchr(arg, 10);
        int wrlFeed = (int)(nL - arg);          //pointer to linefeed argument character
        arg[wrlFeed] = 0;

        return 2;                               //return 2 for command with argument
    }
}

void onlyCmd(char *command)
{
    
    __pid_t p;
    p = fork();

    if (p == -1)
    {
        printf("There was an error calling fork().\n");
    }
    if (p == 0)
    {
        printf("PID of child = %d\n", getpid());
        char *argument[2] = {command, NULL};
        execvp(argument[0], argument);          //execvp(). Its arguments are the commmand and the pointer with NULL as second string
        exit(0);
    }
    else
    {
        wait(NULL);
    }
    return;
}

void cmdwArg(char *cmd, char *arg)
{
    __pid_t p; 
    p = fork(); 
    if (p == -1)
    {
        printf("There was an error calling fork()");
    }
    if (p == 0)
    {
        printf("PID of child = %d\n", getpid());
        char *argument[3] = {cmd, arg, NULL}; 
        execvp(argument[0], argument);           

        exit(0); 
    }
    else
    {
        wait(NULL);     
    }
    return;
}

void cdCall(char *arg)      //Hardcoding of cd call
{
    chdir(arg);
    char ls[] = "ls";
    onlyCmd(ls);
    return;
}
